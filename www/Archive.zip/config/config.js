"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.config = {
    "dev": {},
    "prod": {},
    "jwt": {
        "secret": "hello"
    }
};
//# sourceMappingURL=config.js.map